package com.tirangapay.app;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
public class MainActivity extends Activity {
 @Override public void onCreate(Bundle savedInstanceState){super.onCreate(savedInstanceState); WebView w=new WebView(this); w.setWebViewClient(new WebViewClient()); w.setWebChromeClient(new WebChromeClient()); WebSettings s=w.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); w.loadUrl("file:///android_asset/index.html"); setContentView(w); }
 @Override public void onBackPressed(){ setContentView(new WebView(this)); super.onBackPressed(); }
}