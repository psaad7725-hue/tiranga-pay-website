Tiranga Pay Android Studio project

This is a WebView wrapper source project, not a compiled APK. Open this folder in Android Studio, allow Gradle sync, then Build > Build APK(s).

The included HTML is a front-end preview only. Login/register, payment verification, wallet balance, withdrawals, referral commissions, password changes, and bank-account storage are not backed by a secure server. Do not collect real credentials or deposits until a secure backend and compliant payment provider are implemented.
